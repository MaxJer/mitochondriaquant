import cv2 
import numpy as np
import matplotlib.pyplot as plt
from skimage.io import imread

import streamlit as st 

st.header("This is the cool website")

file = st.upload("Upload your file here", key='upload1')

if file is not None: 
    st.sucess("File Uploaded!!")

threshold = st.slider(min=0, max = 150, default=0)

show_canny = st.radio(0,1)





def getContours(img, cThr=[100,100], showCanny=False, minArea = 0, _filter=0):
    
    #extract ROI
    roi = img[200:400,200:400]
    
    #make a brighter image
    matrix = np.ones(roi.shape) * 2
    img_brighter = np.uint8(cv2.multiply(np.float64(roi),matrix))
    cv2.imwrite("brighter image.png",img_brighter)
    
    cv2.imwrite("ROI.png",roi)
    
    # write original image
    cv2.imwrite("original_img.png",img)
    imgGray = cv2.cvtColor(img_brighter,cv2.COLOR_BGR2GRAY)
    imgBlur = cv2.GaussianBlur(imgGray,(3,3),1)
    cv2.imwrite("blur_img.png",imgBlur)
    imgCanny = cv2.Canny(imgGray, cThr[0], cThr[1])
    
    
    kerneldilate = np.ones((2,2))
    kernelerode = np.ones((1,1))
    imgDial = cv2.dilate(imgCanny, kerneldilate, iterations = 1)
    imgThre = cv2.erode(imgDial, kernelerode, iterations=2)
    
    #if showCanny: cv2.imshow("Canny",imgCanny)
    cv2.imwrite("Dilate.png",imgDial)
    cv2.imwrite("Erode.png",imgThre)
    cv2.imwrite("Canny.png",imgCanny)
    contours, hierachy = cv2.findContours(imgThre, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    
    
    
    
    finalContours = []
    arealst = []
    perimeter = []
    

    for i in contours:
        area = cv2.contourArea(i)
        arealst.append(area)
        peri = cv2.arcLength(i, True)
        perimeter.append(peri)
        approx = cv2.approxPolyDP(i,0.02*peri,True)
        bbox = cv2.boundingRect(approx)
        if _filter > 0:
            if len(approx) == _filter: 
                finalContours.append(len(approx),area,approx,bbox,i)
            else:
                finalContours.append((len(approx),area,approx,bbox,i))

    #all contours
    cv2.drawContours(img_brighter, contours, -1, (255,0,0),1)
    cv2.imwrite("contours.png",img_brighter)   
    
    return img, finalContours, arealst, perimeter



results = get_contours(file)